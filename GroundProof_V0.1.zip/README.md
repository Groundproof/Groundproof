# GroundProof V0.1 — Physical Proof Slice

Ziel des Tests:
QR/Objekt -> Foto -> Proof -> History.

## Was V0.1 bereits demonstriert
- eindeutiges physisches Demo-Objekt `GP-WALL-001`
- mobile Fotoaufnahme über die Gerätekamera
- Statusereignis: Delivered / Verified / Installed / Consumed / Remaining
- Zeitstempel und optionale Notiz
- SHA-256 Hash pro Proof
- Verkettung mit dem vorherigen Proof-Hash
- lokale, append-only gedachte History

## Bewusste Grenzen
- nur ein Demo-Objekt
- lokale Speicherung im Browser (localStorage)
- kein Backend, Login, Cloud-Speicher oder ERP
- Hash-Kette ist ein UX-/Datenmodell-Prototyp, keine rechtssichere Unveränderbarkeitsgarantie
- QR-Scan selbst braucht für einen echten Smartphone-zu-Web-Link eine erreichbare URL; diese V0.1 enthält deshalb noch keine kostenpflichtige Infrastruktur.

## Smartphone-Test
`index.html` ist der eigentliche Prototyp. Sobald er über eine kostenlose HTTPS-URL bereitgestellt ist, kann ein QR-Code direkt auf diese URL bzw. später auf `?asset=GP-WALL-001` zeigen.

Akzeptanzkriterien:
1. Objekt ist nach Öffnen sofort eindeutig.
2. Foto kann direkt mit Smartphone-Kamera aufgenommen werden.
3. Proof ist in <= 30 Sekunden erfassbar.
4. Neuer Eintrag erscheint unmittelbar in der History.
5. Mehrere Einträge ergeben eine verständliche Timeline.
6. Nutzer versteht ohne Erklärung, was als Nächstes zu tun ist.

Nächster Produkt-Slice nach erfolgreichem Physical-Proof-Test:
Count -> Build -> Yield.
